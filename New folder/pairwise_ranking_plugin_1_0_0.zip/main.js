var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => PairwiseRankingPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian = require("obsidian");
var PairwiseRankingPlugin = class extends import_obsidian.Plugin {
  async onload() {
    this.addCommand({
      id: "add-to-ranking",
      name: "Add to Ranking",
      checkCallback: (checking) => {
        const view = this.app.workspace.getActiveViewOfType(import_obsidian.MarkdownView);
        if (view) {
          if (!checking)
            this.promptForNewItem();
          return true;
        }
        return false;
      }
    });
  }
  async promptForNewItem() {
    const file = this.app.workspace.getActiveFile();
    if (!file) {
      new import_obsidian.Notice("Open a note first");
      return;
    }
    const items = await this.readItemsFromFile(file);
    const modal = new import_obsidian.Modal(this.app);
    modal.titleEl.setText("Add to Ranking");
    const input = document.createElement("input");
    input.type = "text";
    input.placeholder = "Enter new item...";
    input.className = "ranking-input";
    requestAnimationFrame(() => {
      input.focus();
    });
    const button = document.createElement("button");
    button.textContent = "Add";
    button.className = "ranking-button";
    const container = modal.contentEl;
    container.appendChild(input);
    container.appendChild(button);
    const onSubmit = async () => {
      const newItem = input.value.trim();
      if (!newItem)
        return;
      modal.close();
      if (items.length === 0) {
        items.push(newItem);
        await this.writeItemsToFile(file, items);
        new import_obsidian.Notice(`Added "${newItem}"`);
      } else {
        const position = await this.findInsertionPosition(newItem, items);
        items.splice(position, 0, newItem);
        await this.writeItemsToFile(file, items);
        new import_obsidian.Notice(`Added "${newItem}" at position ${position + 1}`);
      }
    };
    button.addEventListener("click", onSubmit);
    modal.open();
  }
  async readItemsFromFile(file) {
    try {
      const content = await this.app.vault.read(file);
      return content.split("\n").map((line) => line.trim()).filter((line) => line.length > 0);
    } catch (error) {
      console.error("Error reading file:", error);
      return [];
    }
  }
  async writeItemsToFile(file, items) {
    await this.app.vault.modify(file, items.join("\n"));
  }
  async findInsertionPosition(newItem, items) {
    let left = 0;
    let right = items.length - 1;
    while (left <= right) {
      const mid = Math.floor((left + right) / 2);
      const preference = await this.compareItems(newItem, items[mid]);
      if (preference === "new") {
        right = mid - 1;
      } else {
        left = mid + 1;
      }
    }
    return left;
  }
  async compareItems(a, b) {
    return new Promise((resolve) => {
      const modal = new import_obsidian.Modal(this.app);
      modal.titleEl.setText("Which is better?");
      const container = modal.contentEl;
      const buttonContainer = document.createElement("div");
      buttonContainer.className = "comparison-buttons";
      const newButton = document.createElement("button");
      newButton.textContent = a;
      newButton.className = "comparison-button comparison-button-a";
      const vsSpan = document.createElement("span");
      vsSpan.textContent = " vs ";
      const existingButton = document.createElement("button");
      existingButton.textContent = b;
      existingButton.className = "comparison-button comparison-button-b";
      buttonContainer.appendChild(newButton);
      buttonContainer.appendChild(vsSpan);
      buttonContainer.appendChild(existingButton);
      container.appendChild(buttonContainer);
      const finish = (choice) => {
        modal.close();
        resolve(choice);
      };
      newButton.addEventListener("click", () => finish("new"));
      existingButton.addEventListener("click", () => finish("existing"));
      modal.open();
      requestAnimationFrame(() => {
        newButton.focus();
      });
    });
  }
};
